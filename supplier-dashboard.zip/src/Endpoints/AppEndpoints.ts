export const APIBaseURl = import.meta.env.VITE_APP_URL;

export const LoginEndpoint = `${APIBaseURl}/api/supplier/login`;

