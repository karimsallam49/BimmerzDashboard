import './InventoryPage.css';
import { Search } from 'lucide-react';

const InfoIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="info-icon">
    <circle cx="12" cy="12" r="10"></circle>
    <line x1="12" y1="16" x2="12" y2="12"></line>
    <line x1="12" y1="8" x2="12.01" y2="8"></line>
  </svg>
);

const ExportIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
    <polyline points="7 10 12 15 17 10"></polyline>
    <line x1="12" y1="15" x2="12" y2="3"></line>
  </svg>
);

const ChevronDown = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="6 9 12 15 18 9"></polyline>
  </svg>
);

const SortIcon = () => (
  <svg width="12" height="14" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="sort-icon">
    <path d="M8 17l4 4 4-4" />
    <path d="M8 7l4-4 4 4" />
  </svg>
);

const DocumentBoxEmptyState = () => (
  <div className="empty-illustration">
    <svg width="120" height="100" viewBox="0 0 120 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M45 40h30v40H45V40z" fill="#f1f5f9" />
      <path d="M45 40h30v5H45v-5z" fill="#e2e8f0" />
      <path d="M50 50h20v2H50v-2zM50 55h20v2H50v-2zM50 60h15v2H50v-2z" fill="#cbd5e1" />
      <path d="M35 70l10-10h30l10 10v15H35V70z" fill="#cbd5e1" />
      <path d="M45 60h30v10H45V60z" fill="#e2e8f0" />
      <circle cx="85" cy="30" r="10" fill="#e2e8f0" />
      <circle cx="82" cy="30" r="2" fill="#cbd5e1" />
      <circle cx="88" cy="30" r="2" fill="#cbd5e1" />
      <circle cx="85" cy="30" r="2" fill="#cbd5e1" />
    </svg>
  </div>
);

export const InventoryPage = () => {
  return (
    <div className="inventory-page-container">
      <div className="inventory-header">
        <h1>My Inventory</h1>
        <InfoIcon />
      </div>

      <div className="stock-summary-container">
        <div className="stock-summary-cards">
          <div className="stock-card">
            <div className="stock-card-header">
              <span>Total Stock</span>
              <InfoIcon />
            </div>
            <div className="stock-card-values">
              <span className="stock-items">0 items</span>
              <span className="stock-skus">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                  <polyline points="14 2 14 8 20 8"></polyline>
                  <line x1="16" y1="13" x2="8" y2="13"></line>
                  <line x1="16" y1="17" x2="8" y2="17"></line>
                  <polyline points="10 9 9 9 8 9"></polyline>
                </svg> 
                0 SKUs
              </span>
            </div>
          </div>

          <div className="stock-card border-left">
            <div className="stock-card-header">
              <span>Saleable Stock</span>
              <InfoIcon />
            </div>
            <div className="stock-card-values">
              <span className="stock-items">0 items</span>
            </div>
          </div>

          <div className="stock-card border-left">
            <div className="stock-card-header">
              <span>Non-Saleable Stock</span>
              <InfoIcon />
            </div>
            <div className="stock-card-values">
              <span className="stock-items">0 items</span>
            </div>
          </div>
        </div>
      </div>

      <div className="inventory-tabs-section">
        <div className="inventory-tabs">
          <div className="tab active">
            All Warehouses <span className="tab-badge blue">0</span>
          </div>
          <div className="tab">
            Saleable <span className="tab-badge">0</span>
          </div>
          <div className="tab">
            Non-Saleable <span className="tab-badge">0</span>
          </div>
        </div>
        <div className="last-updated">
          <InfoIcon /> Last Updated: 2026-03-14 10:42 AM
        </div>
      </div>

      <div className="inventory-filters">
        <div className="search-input-wrapper">
          <input type="text" placeholder="Search for SKU here..." />
          <div className="search-icon-divider"></div>
          <div className="search-icon-wrapper">
            <Search size={18} color="#9ca3af" />
          </div>
        </div>
        
        <div className="filter-actions-right">
          <button className="dropdown-btn">
            Warehouse Name <ChevronDown />
          </button>
          <button className="dropdown-btn">
            Warehouse Type <ChevronDown />
          </button>
          <div className="vertical-divider"></div>
          <button className="export-btn">
            <ExportIcon /> Export
          </button>
        </div>
      </div>

      <div className="inventory-table-container">
        <table className="inventory-table">
          <thead>
            <tr>
              <th>Product</th>
              <th>Dimensions</th>
              <th>SKU</th>
              <th>Pbarcode</th>
              <th>Warehouse</th>
              <th>Saleable <SortIcon /></th>
              <th>Non-Saleable <SortIcon /></th>
              <th>Total Stock <SortIcon /></th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colSpan={8} className="empty-state-cell">
                <div className="empty-state-wrapper">
                  <DocumentBoxEmptyState />
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
