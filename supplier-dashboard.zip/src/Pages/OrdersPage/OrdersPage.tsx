import { useState, useMemo, useCallback } from 'react'
import { Card, Form, Button, Row, Col, Table, Badge, InputGroup, Modal } from 'react-bootstrap'

interface Order {
  id: string
  orderNumber: string
  customerName: string
  customerEmail: string
  orderDate: string
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled'
  totalAmount: number
  itemCount: number
  paymentMethod: string
  shippingAddress: string
}

export const OrdersPage = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedStatus, setSelectedStatus] = useState('')
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [showDetailsModal, setShowDetailsModal] = useState(false)
  const [orders, _setOrders] = useState<Order[]>([
    { id: '1', orderNumber: 'ORD-2024-001', customerName: 'John Doe', customerEmail: 'john@example.com', orderDate: '2024-03-10', status: 'pending', totalAmount: 245.99, itemCount: 3, paymentMethod: 'Credit Card', shippingAddress: '123 Main St, City, State 12345' },
    { id: '2', orderNumber: 'ORD-2024-002', customerName: 'Jane Smith', customerEmail: 'jane@example.com', orderDate: '2024-03-11', status: 'processing', totalAmount: 189.50, itemCount: 2, paymentMethod: 'PayPal', shippingAddress: '456 Oak Ave, Town, State 67890' },
    { id: '3', orderNumber: 'ORD-2024-003', customerName: 'Bob Johnson', customerEmail: 'bob@example.com', orderDate: '2024-03-09', status: 'shipped', totalAmount: 425.00, itemCount: 5, paymentMethod: 'Credit Card', shippingAddress: '789 Pine Rd, Village, State 11111' },
    { id: '4', orderNumber: 'ORD-2024-004', customerName: 'Alice Brown', customerEmail: 'alice@example.com', orderDate: '2024-03-08', status: 'delivered', totalAmount: 156.75, itemCount: 2, paymentMethod: 'Bank Transfer', shippingAddress: '321 Elm St, City, State 22222' },
    { id: '5', orderNumber: 'ORD-2024-005', customerName: 'Charlie Wilson', customerEmail: 'charlie@example.com', orderDate: '2024-03-07', status: 'cancelled', totalAmount: 89.99, itemCount: 1, paymentMethod: 'Credit Card', shippingAddress: '654 Maple Dr, Town, State 33333' }
  ])

  const filteredOrders = useMemo(() => orders.filter(order => {
    const matchesSearch = order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.customerEmail.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = !selectedStatus || order.status === selectedStatus
    return matchesSearch && matchesStatus
  }), [orders, searchTerm, selectedStatus])

  const getStatusBadge = useCallback((status: string) => {
    switch(status) {
      case 'pending': return <Badge bg="warning">Pending</Badge>
      case 'processing': return <Badge bg="info">Processing</Badge>
      case 'shipped': return <Badge bg="primary">Shipped</Badge>
      case 'delivered': return <Badge bg="success">Delivered</Badge>
      case 'cancelled': return <Badge bg="danger">Cancelled</Badge>
      default: return <Badge bg="secondary">{status}</Badge>
    }
  }, [])

  const handleViewDetails = useCallback((order: Order) => {
    setSelectedOrder(order)
    setShowDetailsModal(true)
  }, [])

  const pendingOrders = useMemo(() => orders.filter(order => order.status === 'pending'), [orders])
  const processingOrders = useMemo(() => orders.filter(order => order.status === 'processing'), [orders])

  return (
    <div className="orders-page">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Order Management</h2>
        <Button variant="primary">
          <i className="bi bi-plus-circle me-2"></i>
          Create Order
        </Button>
      </div>

      {/* Summary Cards */}
      <Row className="mb-4">
        <Col md={2}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-primary">{orders.length}</h3>
              <p className="mb-0">Total Orders</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={2}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-warning">{pendingOrders.length}</h3>
              <p className="mb-0">Pending</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={2}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-info">{processingOrders.length}</h3>
              <p className="mb-0">Processing</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={2}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-primary">{orders.filter(o => o.status === 'shipped').length}</h3>
              <p className="mb-0">Shipped</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={2}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-success">{orders.filter(o => o.status === 'delivered').length}</h3>
              <p className="mb-0">Delivered</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={2}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-danger">{orders.filter(o => o.status === 'cancelled').length}</h3>
              <p className="mb-0">Cancelled</p>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Card className="mb-4">
        <Card.Body>
          <Row>
            <Col md={4}>
              <InputGroup>
                <Form.Control
                  placeholder="Search orders..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Button variant="outline-secondary">
                  <i className="bi bi-search"></i>
                </Button>
              </InputGroup>
            </Col>
            <Col md={3}>
              <Form.Select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
              >
                <option value="">All Status</option>
                <option value="pending">Pending</option>
                <option value="processing">Processing</option>
                <option value="shipped">Shipped</option>
                <option value="delivered">Delivered</option>
                <option value="cancelled">Cancelled</option>
              </Form.Select>
            </Col>
            <Col md={5}>
              <div className="d-flex gap-2">
                <Button variant="outline-primary">
                  <i className="bi bi-download me-2"></i>
                  Export
                </Button>
                <Button variant="outline-info">
                  <i className="bi bi-truck me-2"></i>
                  Bulk Ship
                </Button>
                <Button variant="outline-success">
                  <i className="bi bi-envelope me-2"></i>
                  Send Notifications
                </Button>
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      <Card>
        <Card.Body>
          <h5 className="mb-3">Orders ({filteredOrders.length})</h5>

          <Table responsive hover>
            <thead>
              <tr>
                <th>Order Number</th>
                <th>Customer</th>
                <th>Email</th>
                <th>Order Date</th>
                <th>Status</th>
                <th>Items</th>
                <th>Total Amount</th>
                <th>Payment Method</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredOrders.map(order => (
                <tr key={order.id}>
                  <td className="fw-bold">{order.orderNumber}</td>
                  <td>{order.customerName}</td>
                  <td>{order.customerEmail}</td>
                  <td>{order.orderDate}</td>
                  <td>{getStatusBadge(order.status)}</td>
                  <td>{order.itemCount}</td>
                  <td className="fw-bold text-primary">${order.totalAmount.toFixed(2)}</td>
                  <td>{order.paymentMethod}</td>
                  <td>
                    <div className="btn-group" role="group">
                      <Button variant="outline-info" size="sm" onClick={() => handleViewDetails(order)}>
                        <i className="bi bi-eye"></i>
                      </Button>
                      <Button variant="outline-primary" size="sm">
                        <i className="bi bi-pencil"></i>
                      </Button>
                      <Button variant="outline-success" size="sm">
                        <i className="bi bi-truck"></i>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>

          {filteredOrders.length === 0 && (
            <div className="text-center py-4">
              <i className="bi bi-bag-check display-4 text-muted"></i>
              <p className="text-muted mt-2">No orders found</p>
            </div>
          )}
        </Card.Body>
      </Card>

      {/* Order Details Modal */}
      <Modal show={showDetailsModal} onHide={() => setShowDetailsModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Order Details - {selectedOrder?.orderNumber}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedOrder && (
            <Row>
              <Col md={6}>
                <h6>Customer Information</h6>
                <p><strong>Name:</strong> {selectedOrder.customerName}</p>
                <p><strong>Email:</strong> {selectedOrder.customerEmail}</p>
                <p><strong>Shipping Address:</strong> {selectedOrder.shippingAddress}</p>
              </Col>
              <Col md={6}>
                <h6>Order Information</h6>
                <p><strong>Order Date:</strong> {selectedOrder.orderDate}</p>
                <p><strong>Status:</strong> {getStatusBadge(selectedOrder.status)}</p>
                <p><strong>Payment Method:</strong> {selectedOrder.paymentMethod}</p>
                <p><strong>Total Amount:</strong> ${selectedOrder.totalAmount.toFixed(2)}</p>
                <p><strong>Items:</strong> {selectedOrder.itemCount}</p>
              </Col>
            </Row>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDetailsModal(false)}>
            Close
          </Button>
          <Button variant="primary">
            Update Status
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  )
}
