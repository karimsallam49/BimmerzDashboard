import './ProductListPage.css';

export const ProductListPage = () => {
  return (
    <div className="product-list-page">
      <div className="page-header">
        <h1>Product List</h1>
        <div className="header-actions">
          <button className="btn btn-outline">Export</button>
          <button className="btn btn-primary">Add Product</button>
        </div>
      </div>

      <div className="filters-section">
        <div className="search-bar">
          <input type="text" placeholder="Search products..." className="search-input" />
          <button className="search-btn">🔍</button>
        </div>
        
        <div className="filters">
          <select className="filter-select">
            <option>All Categories</option>
            <option>Electronics</option>
            <option>Clothing</option>
            <option>Home & Kitchen</option>
          </select>
          
          <select className="filter-select">
            <option>All Status</option>
            <option>Active</option>
            <option>Inactive</option>
            <option>Draft</option>
          </select>
          
          <select className="filter-select">
            <option>All Brands</option>
            <option>Bosch</option>
            <option>Samsung</option>
            <option>Sony</option>
          </select>
        </div>
      </div>

      <div className="products-table">
        <div className="table-header">
          <div className="table-info">
            <span>Showing 1-10 of 156 products</span>
          </div>
          <div className="table-actions">
            <select className="per-page-select">
              <option>10 per page</option>
              <option>25 per page</option>
              <option>50 per page</option>
            </select>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>
                <input type="checkbox" />
              </th>
              <th>Product</th>
              <th>SKU</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Status</th>
              <th>Brand</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td><input type="checkbox" /></td>
              <td>
                <div className="product-cell">
                  <div className="product-image"></div>
                  <div className="product-info">
                    <h4>Bosch Washing Machine</h4>
                    <p>Front Load, 8kg</p>
                  </div>
                </div>
              </td>
              <td>BWM-001</td>
              <td>EGP 12,999</td>
              <td>45</td>
              <td><span className="status active">Active</span></td>
              <td>Bosch</td>
              <td>
                <div className="action-buttons">
                  <button className="btn-icon">✏️</button>
                  <button className="btn-icon">👁️</button>
                  <button className="btn-icon">🗑️</button>
                </div>
              </td>
            </tr>
            <tr>
              <td><input type="checkbox" /></td>
              <td>
                <div className="product-cell">
                  <div className="product-image"></div>
                  <div className="product-info">
                    <h4>Samsung TV 55"</h4>
                    <p>Smart TV, 4K</p>
                  </div>
                </div>
              </td>
              <td>STV-002</td>
              <td>EGP 8,999</td>
              <td>12</td>
              <td><span className="status active">Active</span></td>
              <td>Samsung</td>
              <td>
                <div className="action-buttons">
                  <button className="btn-icon">✏️</button>
                  <button className="btn-icon">👁️</button>
                  <button className="btn-icon">🗑️</button>
                </div>
              </td>
            </tr>
            <tr>
              <td><input type="checkbox" /></td>
              <td>
                <div className="product-cell">
                  <div className="product-image"></div>
                  <div className="product-info">
                    <h4>Sony Headphones</h4>
                    <p>Wireless, Noise Cancelling</p>
                  </div>
                </div>
              </td>
              <td>SH-003</td>
              <td>EGP 2,499</td>
              <td>0</td>
              <td><span className="status inactive">Out of Stock</span></td>
              <td>Sony</td>
              <td>
                <div className="action-buttons">
                  <button className="btn-icon">✏️</button>
                  <button className="btn-icon">👁️</button>
                  <button className="btn-icon">🗑️</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>

        <div className="pagination">
          <button className="page-btn" disabled>Previous</button>
          <button className="page-btn active">1</button>
          <button className="page-btn">2</button>
          <button className="page-btn">3</button>
          <button className="page-btn">...</button>
          <button className="page-btn">16</button>
          <button className="page-btn">Next</button>
        </div>
      </div>
    </div>
  );
};
