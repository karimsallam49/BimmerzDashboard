import { useState } from 'react'
import { Card, Form, Button, Row, Col, Badge, Table } from 'react-bootstrap'

interface Transaction {
  id: string
  transactionId: string
  date: string
  customer: string
  amount: number
  method: 'credit-card' | 'paypal' | 'bank-transfer' | 'cash'
  status: 'completed' | 'pending' | 'failed' | 'refunded'
  orderNumber: string
  fees: number
  netAmount: number
}

interface PaymentMethod {
  id: string
  name: string
  type: string
  status: 'active' | 'inactive'
  transactions: number
  revenue: number
}

export const PaymentsPage = () => {
  const [selectedStatus, setSelectedStatus] = useState('')
  const [selectedMethod, setSelectedMethod] = useState('')
  const [transactions, _setTransactions] = useState<Transaction[]>([
    {
      id: '1',
      transactionId: 'TXN-001234',
      date: '2024-03-11 14:30',
      customer: 'John Doe',
      amount: 245.99,
      method: 'credit-card',
      status: 'completed',
      orderNumber: 'ORD-2024-001',
      fees: 7.38,
      netAmount: 238.61
    },
    {
      id: '2',
      transactionId: 'TXN-001235',
      date: '2024-03-11 13:15',
      customer: 'Jane Smith',
      amount: 189.50,
      method: 'paypal',
      status: 'completed',
      orderNumber: 'ORD-2024-002',
      fees: 5.69,
      netAmount: 183.81
    },
    {
      id: '3',
      transactionId: 'TXN-001236',
      date: '2024-03-11 11:45',
      customer: 'Bob Johnson',
      amount: 425.00,
      method: 'bank-transfer',
      status: 'pending',
      orderNumber: 'ORD-2024-003',
      fees: 12.75,
      netAmount: 412.25
    },
    {
      id: '4',
      transactionId: 'TXN-001237',
      date: '2024-03-10 16:20',
      customer: 'Alice Brown',
      amount: 156.75,
      method: 'credit-card',
      status: 'failed',
      orderNumber: 'ORD-2024-004',
      fees: 0,
      netAmount: 0
    },
    {
      id: '5',
      transactionId: 'TXN-001238',
      date: '2024-03-10 09:30',
      customer: 'Charlie Wilson',
      amount: 89.99,
      method: 'paypal',
      status: 'refunded',
      orderNumber: 'ORD-2024-005',
      fees: 2.70,
      netAmount: -92.69
    }
  ])

  const paymentMethods: PaymentMethod[] = [
    { id: '1', name: 'Credit Card', type: 'Stripe', status: 'active', transactions: 234, revenue: 45600 },
    { id: '2', name: 'PayPal', type: 'PayPal', status: 'active', transactions: 156, revenue: 28900 },
    { id: '3', name: 'Bank Transfer', type: 'Direct', status: 'active', transactions: 45, revenue: 12300 },
    { id: '4', name: 'Cash on Delivery', type: 'Manual', status: 'inactive', transactions: 0, revenue: 0 }
  ]

  const filteredTransactions = transactions.filter(transaction => {
    const matchesStatus = !selectedStatus || transaction.status === selectedStatus
    const matchesMethod = !selectedMethod || transaction.method === selectedMethod
    return matchesStatus && matchesMethod
  })

  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'completed': return <Badge bg="success">Completed</Badge>
      case 'pending': return <Badge bg="warning">Pending</Badge>
      case 'failed': return <Badge bg="danger">Failed</Badge>
      case 'refunded': return <Badge bg="info">Refunded</Badge>
      default: return <Badge bg="secondary">{status}</Badge>
    }
  }

  const getMethodBadge = (method: string) => {
    switch(method) {
      case 'credit-card': return <Badge bg="primary">Credit Card</Badge>
      case 'paypal': return <Badge bg="info">PayPal</Badge>
      case 'bank-transfer': return <Badge bg="success">Bank Transfer</Badge>
      case 'cash': return <Badge bg="secondary">Cash</Badge>
      default: return <Badge bg="secondary">{method}</Badge>
    }
  }

  const totalRevenue = transactions.filter(t => t.status === 'completed').reduce((sum, t) => sum + t.netAmount, 0)
  const pendingAmount = transactions.filter(t => t.status === 'pending').reduce((sum, t) => sum + t.amount, 0)
  const totalFees = transactions.reduce((sum, t) => sum + t.fees, 0)

  return (
    <div className="payments-page">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Payment Management</h2>
        <Button variant="primary">
          <i className="bi bi-plus-circle me-2"></i>
          Process Refund
        </Button>
      </div>

      {/* Summary Cards */}
      <Row className="mb-4">
        <Col md={3}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-success">${totalRevenue.toLocaleString()}</h3>
              <p className="mb-0">Total Revenue</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-warning">${pendingAmount.toLocaleString()}</h3>
              <p className="mb-0">Pending Amount</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-info">${totalFees.toLocaleString()}</h3>
              <p className="mb-0">Total Fees</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="text-center">
            <Card.Body>
              <h3 className="text-primary">{transactions.length}</h3>
              <p className="mb-0">Transactions</p>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* Payment Methods */}
      <Card className="mb-4">
        <Card.Body>
          <h5 className="mb-3">Payment Methods</h5>
          <Row>
            {paymentMethods.map(method => (
              <Col md={3} key={method.id}>
                <Card className={`h-100 ${method.status === 'inactive' ? 'opacity-50' : ''}`}>
                  <Card.Body className="text-center">
                    <i className={`bi bi-credit-card display-6 ${method.status === 'active' ? 'text-primary' : 'text-muted'} mb-2`}></i>
                    <h6>{method.name}</h6>
                    <p className="text-muted small mb-1">{method.type}</p>
                    <Badge bg={method.status === 'active' ? 'success' : 'secondary'}>
                      {method.status}
                    </Badge>
                    <div className="mt-2">
                      <small className="text-muted">{method.transactions} transactions</small><br/>
                      <small className="text-muted">${method.revenue.toLocaleString()} revenue</small>
                    </div>
                  </Card.Body>
                </Card>
              </Col>
            ))}
          </Row>
        </Card.Body>
      </Card>

      <Card className="mb-4">
        <Card.Body>
          <Row>
            <Col md={4}>
              <Form.Select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
              >
                <option value="">All Status</option>
                <option value="completed">Completed</option>
                <option value="pending">Pending</option>
                <option value="failed">Failed</option>
                <option value="refunded">Refunded</option>
              </Form.Select>
            </Col>
            <Col md={4}>
              <Form.Select
                value={selectedMethod}
                onChange={(e) => setSelectedMethod(e.target.value)}
              >
                <option value="">All Methods</option>
                <option value="credit-card">Credit Card</option>
                <option value="paypal">PayPal</option>
                <option value="bank-transfer">Bank Transfer</option>
                <option value="cash">Cash</option>
              </Form.Select>
            </Col>
            <Col md={4}>
              <div className="d-flex gap-2">
                <Button variant="outline-primary">
                  <i className="bi bi-download me-2"></i>
                  Export
                </Button>
                <Button variant="outline-info">
                  <i className="bi bi-arrow-repeat me-2"></i>
                  Sync
                </Button>
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      <Card>
        <Card.Body>
          <h5 className="mb-3">Recent Transactions ({filteredTransactions.length})</h5>

          <Table responsive hover>
            <thead>
              <tr>
                <th>Transaction ID</th>
                <th>Date</th>
                <th>Customer</th>
                <th>Order</th>
                <th>Amount</th>
                <th>Method</th>
                <th>Status</th>
                <th>Fees</th>
                <th>Net Amount</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTransactions.map(transaction => (
                <tr key={transaction.id}>
                  <td className="fw-bold">{transaction.transactionId}</td>
                  <td>{transaction.date}</td>
                  <td>{transaction.customer}</td>
                  <td>{transaction.orderNumber}</td>
                  <td>${transaction.amount.toFixed(2)}</td>
                  <td>{getMethodBadge(transaction.method)}</td>
                  <td>{getStatusBadge(transaction.status)}</td>
                  <td>${transaction.fees.toFixed(2)}</td>
                  <td className="fw-bold">${transaction.netAmount.toFixed(2)}</td>
                  <td>
                    <div className="btn-group" role="group">
                      <Button variant="outline-info" size="sm">
                        <i className="bi bi-eye"></i>
                      </Button>
                      <Button variant="outline-warning" size="sm">
                        <i className="bi bi-arrow-left-right"></i>
                      </Button>
                      <Button variant="outline-success" size="sm">
                        <i className="bi bi-receipt"></i>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>

          {filteredTransactions.length === 0 && (
            <div className="text-center py-4">
              <i className="bi bi-credit-card display-4 text-muted"></i>
              <p className="text-muted mt-2">No transactions found</p>
            </div>
          )}
        </Card.Body>
      </Card>
    </div>
  )
}
