import { useState, useMemo, useCallback } from 'react'
import { Card, Form, Button, Row, Col, Table, Badge, InputGroup } from 'react-bootstrap'

interface CatalogItem {
  id: string
  name: string
  sku: string
  category: string
  brand: string
  price: number
  stock: number
  status: 'active' | 'inactive'
}

export const CatalogPage = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('')
  const [catalogItems, setCatalogItems] = useState<CatalogItem[]>([
    { id: '1', name: 'Brake Pads Front', sku: 'BP-001', category: 'Brakes', brand: 'Brembo', price: 89.99, stock: 50, status: 'active' },
    { id: '2', name: 'Oil Filter', sku: 'OF-002', category: 'Filters', brand: 'Bosch', price: 15.99, stock: 100, status: 'active' },
    { id: '3', name: 'Spark Plugs', sku: 'SP-003', category: 'Ignition', brand: 'NGK', price: 45.99, stock: 75, status: 'active' },
    { id: '4', name: 'Air Filter', sku: 'AF-004', category: 'Filters', brand: 'Mann-Filter', price: 25.99, stock: 60, status: 'inactive' },
    { id: '5', name: 'Brake Discs', sku: 'BD-005', category: 'Brakes', brand: 'Brembo', price: 120.99, stock: 30, status: 'active' },
    { id: '6', name: 'Water Pump', sku: 'WP-006', category: 'Cooling', brand: 'Aisin', price: 85.99, stock: 25, status: 'active' }
  ])

  const categories = useMemo(() => ['All', 'Brakes', 'Filters', 'Ignition', 'Cooling', 'Suspension', 'Transmission'], [])

  const filteredItems = useMemo(() => {
    return catalogItems.filter(item => {
      const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           item.sku.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = !selectedCategory || selectedCategory === 'All' || item.category === selectedCategory
      return matchesSearch && matchesCategory
    })
  }, [catalogItems, searchTerm, selectedCategory])

  const handleStatusToggle = useCallback((id: string) => {
    setCatalogItems(prev => 
      prev.map(item => 
        item.id === id 
          ? { ...item, status: item.status === 'active' ? 'inactive' : 'active' }
          : item
      )
    )
  }, [])

  return (
    <div className="catalog-page">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Product Catalog</h2>
        <Button variant="primary">
          <i className="bi bi-plus-circle me-2"></i>
          Add New Product
        </Button>
      </div>

      <Card className="mb-4">
        <Card.Body>
          <Row>
            <Col md={6}>
              <InputGroup>
                <Form.Control
                  placeholder="Search products..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <Button variant="outline-secondary">
                  <i className="bi bi-search"></i>
                </Button>
              </InputGroup>
            </Col>
            <Col md={3}>
              <Form.Select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </Form.Select>
            </Col>
            <Col md={3}>
              <div className="d-flex gap-2">
                <Button variant="outline-primary">
                  <i className="bi bi-download me-2"></i>
                  Export
                </Button>
                <Button variant="outline-secondary">
                  <i className="bi bi-upload me-2"></i>
                  Import
                </Button>
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      <Card>
        <Card.Body>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h5>Catalog Items ({filteredItems.length})</h5>
            <div>
              <Badge bg="success" className="me-2">
                {catalogItems.filter(item => item.status === 'active').length} Active
              </Badge>
              <Badge bg="secondary">
                {catalogItems.filter(item => item.status === 'inactive').length} Inactive
              </Badge>
            </div>
          </div>

          <Table responsive hover>
            <thead>
              <tr>
                <th>SKU</th>
                <th>Product Name</th>
                <th>Category</th>
                <th>Brand</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map(item => (
                <tr key={item.id}>
                  <td>{item.sku}</td>
                  <td>{item.name}</td>
                  <td>{item.category}</td>
                  <td>{item.brand}</td>
                  <td>${item.price.toFixed(2)}</td>
                  <td>{item.stock}</td>
                  <td>
                    <Badge bg={item.status === 'active' ? 'success' : 'secondary'}>
                      {item.status}
                    </Badge>
                  </td>
                  <td>
                    <div className="btn-group" role="group">
                      <Button variant="outline-primary" size="sm">
                        <i className="bi bi-pencil"></i>
                      </Button>
                      <Button 
                        variant={item.status === 'active' ? 'outline-warning' : 'outline-success'} 
                        size="sm"
                        onClick={() => handleStatusToggle(item.id)}
                      >
                        <i className={`bi bi-${item.status === 'active' ? 'pause' : 'play'}`}></i>
                      </Button>
                      <Button variant="outline-danger" size="sm">
                        <i className="bi bi-trash"></i>
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>

          {filteredItems.length === 0 && (
            <div className="text-center py-4">
              <i className="bi bi-box display-4 text-muted"></i>
              <p className="text-muted mt-2">No products found in catalog</p>
            </div>
          )}
        </Card.Body>
      </Card>
    </div>
  )
}
