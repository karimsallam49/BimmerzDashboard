import React, { useState } from 'react'
import TECHNICAL_LITERATURE from "../../assets/Images/AddbyCategory/group_01-00-P.webp"
import SERVICEANDSCOPEOFREPAIRWORKPIC from "../../assets/Images/AddbyCategory/group_02-00-P.webp"
import RETROFITTINGCONVERSIONACCESSORIESPIC from "../../assets/Images/AddbyCategory/group_03-00-P.webp"
import PARTSREPAIRSERVICEPIC from "../../assets/Images/AddbyCategory/group_11-00-P.webp"
import ENGINE from "../../assets/Images/AddbyCategory/group_11-00-P.webp"
import ENGINEELECTRICALSYSTEM from "../../assets/Images/AddbyCategory/group_12-00-P.webp"
import FUELPREPARATIONSYSTEM from "../../assets/Images/AddbyCategory/group_13-00-P.webp"
import FUELSUPPLY from "../../assets/Images/AddbyCategory/group_16-00-P.webp"
import RADIATOR from "../../assets/Images/AddbyCategory/group_17-00-P.webp"
import EXHAUSTSYSTEM from "../../assets/Images/AddbyCategory/group_18-00-P.webp"
import CLUTCH from "../../assets/Images/AddbyCategory/group_21-00-P.webp"
import ENGINEANDTRANSMISSIONSUSPENSION from "../../assets/Images/AddbyCategory/group_22-00-P.webp"
import MANUALTRANSMISSION from "../../assets/Images/AddbyCategory/group_23-00-P.webp"
import AUTOMATICTRANSMISSION from "../../assets/Images/AddbyCategory/group_24-00-P.webp"
import GEARSHIFT from "../../assets/Images/AddbyCategory/group_25-00-P.webp"
import DRIVE_SHAFT from "../../assets/Images/AddbyCategory/group_26-00-P.webp"
import FRONT_AXLE from "../../assets/Images/AddbyCategory/group_31-00-P.webp"
import STEERING from "../../assets/Images/AddbyCategory/group_32-00-P.webp"
import REAR_AXLE from "../../assets/Images/AddbyCategory/group_33-00-P.webp"
import BRAKES from "../../assets/Images/AddbyCategory/group_34-00-P.webp"
import PEDALS from "../../assets/Images/AddbyCategory/group_35-00-P.webp"
import WHEELS from "../../assets/Images/AddbyCategory/group_36-00-P.webp"
import BODYWORK from "../../assets/Images/AddbyCategory/group_41-00-P.webp"
import VEHICLE_TRIM from "../../assets/Images/AddbyCategory/group_51-00-P.webp"
import SEATS from "../../assets/Images/AddbyCategory/group_52-00-P.webp"
import SLIDING_ROOF_FOLDING_TOP from "../../assets/Images/AddbyCategory/group_54-00-P.webp"
import VEHICLE_ELECTRICAL_SYSTEM from "../../assets/Images/AddbyCategory/group_61-00-P.webp"
import INSTRUMENTS_MEASURING_SYSTEMS from "../../assets/Images/AddbyCategory/group_62-00-P.webp"
import LIGHTING from "../../assets/Images/AddbyCategory/group_63-00-P.webp"
import HEATER_AND_AIR_CONDITIONING from "../../assets/Images/AddbyCategory/group_64-00-P.webp"
import AUDIO_NAVIGATION_ELECTRONIC_SYSTEMS from "../../assets/Images/AddbyCategory/group_65-00-P.webp"
import DISTANCE_SYSTEMS_CRUISE_CONTROL from "../../assets/Images/AddbyCategory/group_66-00-P.webp"
import EQUIPMENT_PARTS from "../../assets/Images/AddbyCategory/group_71-00-P.webp"
import RESTRAINT_SYSTEM_AND_ACCESSORIES from "../../assets/Images/AddbyCategory/group_72-00-P.webp"
import AUXILIARY_MATERIALS_FLUIDS_COLORSYSTEM from "../../assets/Images/AddbyCategory/group_83-00-P.webp"
import COMMUNICATION_SYSTEMS from "../../assets/Images/AddbyCategory/group_84-00-P.webp"
import VALUE_PARTS_PACKAGES_SERVICE_AND_REPAIR from "../../assets/Images/AddbyCategory/group_88-00-P.webp"
import INDIVIDUAL_EQUIPMENT from "../../assets/Images/AddbyCategory/group_91-00-P.webp"
interface CatalogProduct {
  id: string
  name: string
  sku: string
  price: number
  category: string
  brand: string
  stock: number
  image: string
  selected: boolean
}
import "./AddBycategory.css"
const bmwModels = [
  { id: 'series1', name: '1 Series', years: [2026, 2025, 2024, 2023, 2022] },
  { id: 'series2', name: '2 Series', years: [2026, 2025, 2024, 2023] },
  { id: 'series3', name: '3 Series', years: [2026, 2025, 2024, 2023, 2022, 2021] },
  { id: 'series4', name: '4 Series', years: [2026, 2025, 2024, 2023] },
  { id: 'series5', name: '5 Series', years: [2026, 2025, 2024, 2023, 2022, 2021] },
  { id: 'series6', name: '6 Series', years: [2025, 2024, 2023] },
  { id: 'series7', name: '7 Series', years: [2026, 2025, 2024] },
  { id: 'x1', name: 'X1', years: [2026, 2025, 2024, 2023] },
  { id: 'x3', name: 'X3', years: [2026, 2025, 2024, 2023] },
  { id: 'x5', name: 'X5', years: [2026, 2025, 2024, 2023, 2022] },
  { id: 'x6', name: 'X6', years: [2026, 2025, 2024] },
  { id: 'z4', name: 'Z4', years: [2026, 2025, 2024] }
]

const getYears = () => {
  const currentYear = new Date().getFullYear()
  const years = []
  for (let year = currentYear; year >= currentYear - 10; year--) years.push(year)
  return years
}

export const AddByCatalogPage = () => {
  const [selectedModel, setSelectedModel] = useState('')
  const [selectedYear, setSelectedYear] = useState('')
  const [searchPerformed, setSearchPerformed] = useState(false)
  const [catalogProducts, setCatalogProducts] = useState<CatalogProduct[]>([])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    const mockProducts: CatalogProduct[] = [
      { id: '1', name: 'TECHNICAL LITERATURE', sku: 'BP-001', price: 89.99, category: 'Documentation', brand: 'BMW', stock: 50, image: TECHNICAL_LITERATURE, selected: false },
      { id: '2', name: 'SERVICE AND SCOPE OF REPAIR WORK', sku: 'OF-002', price: 15.99, category: 'Service', brand: 'BMW', stock: 100, image: SERVICEANDSCOPEOFREPAIRWORKPIC, selected: false },
      { id: '3', name: 'RETROFITTING / CONVERSION / ACCESSORIES', sku: 'SP-003', price: 45.99, category: 'Accessories', brand: 'BMW', stock: 75, image: RETROFITTINGCONVERSIONACCESSORIESPIC, selected: false },
      { id: '4', name: 'PARTS REPAIR SERVICE', sku: 'AF-004', price: 25.99, category: 'Repair', brand: 'BMW', stock: 60, image: PARTSREPAIRSERVICEPIC, selected: false },
      { id: '5', name: 'ENGINE', sku: 'BD-005', price: 120.99, category: 'Engine', brand: 'BMW', stock: 30, image: ENGINE, selected: false },
      { id: '6', name: 'ENGINE ELECTRICAL SYSTEM', sku: 'WP-006', price: 85.99, category: 'Electrical', brand: 'BMW', stock: 25, image: ENGINEELECTRICALSYSTEM, selected: false },
      { id: '7', name: 'FUEL PREPARATION SYSTEM', sku: 'TB-007', price: 65.99, category: 'Fuel', brand: 'BMW', stock: 40, image: FUELPREPARATIONSYSTEM, selected: false },
      { id: '8', name: 'FUEL SUPPLY', sku: 'SA-008', price: 150.99, category: 'Fuel', brand: 'BMW', stock: 20, image: FUELSUPPLY, selected: false },
      { id: '9', name: 'RADIATOR', sku: 'RD-009', price: 95.99, category: 'Cooling', brand: 'BMW', stock: 35, image: RADIATOR, selected: false },
      { id: '10', name: 'EXHAUST SYSTEM', sku: 'ES-010', price: 200.99, category: 'Exhaust', brand: 'BMW', stock: 15, image: EXHAUSTSYSTEM, selected: false },
      { id: '11', name: 'CLUTCH', sku: 'CL-011', price: 180.99, category: 'Transmission', brand: 'BMW', stock: 22, image: CLUTCH, selected: false },
      { id: '12', name: 'ENGINE AND TRANSMISSION SUSPENSION', sku: 'TS-012', price: 250.99, category: 'Suspension', brand: 'BMW', stock: 18, image: ENGINEANDTRANSMISSIONSUSPENSION, selected: false },
      { id: '13', name: 'MANUAL TRANSMISSION', sku: 'MT-013', price: 350.99, category: 'Transmission', brand: 'BMW', stock: 12, image: MANUALTRANSMISSION, selected: false },
      { id: '14', name: 'AUTOMATIC TRANSMISSION', sku: 'AT-014', price: 450.99, category: 'Transmission', brand: 'BMW', stock: 10, image: AUTOMATICTRANSMISSION, selected: false },
      { id: '15', name: 'GEARSHIFT', sku: 'GS-015', price: 120.99, category: 'Transmission', brand: 'BMW', stock: 28, image: GEARSHIFT, selected: false },
      { id: '16', name: 'DRIVE SHAFT', sku: 'DS-016', price: 160.99, category: 'Drivetrain', brand: 'BMW', stock: 20, image: DRIVE_SHAFT, selected: false },
      { id: '17', name: 'FRONT AXLE', sku: 'FA-017', price: 220.99, category: 'Axle', brand: 'BMW', stock: 16, image: FRONT_AXLE, selected: false },
      { id: '18', name: 'STEERING', sku: 'ST-018', price: 180.99, category: 'Steering', brand: 'BMW', stock: 24, image: STEERING, selected: false },
      { id: '19', name: 'REAR AXLE', sku: 'RA-019', price: 240.99, category: 'Axle', brand: 'BMW', stock: 14, image: REAR_AXLE, selected: false },
      { id: '20', name: 'BRAKES', sku: 'BR-020', price: 140.99, category: 'Brakes', brand: 'BMW', stock: 45, image: BRAKES, selected: false },
      { id: '21', name: 'PEDALS', sku: 'PD-021', price: 80.99, category: 'Controls', brand: 'BMW', stock: 32, image: PEDALS, selected: false },
      { id: '22', name: 'WHEELS', sku: 'WH-022', price: 320.99, category: 'Wheels', brand: 'BMW', stock: 25, image: WHEELS, selected: false },
      { id: '23', name: 'BODYWORK', sku: 'BW-023', price: 180.99, category: 'Body', brand: 'BMW', stock: 30, image: BODYWORK, selected: false },
      { id: '24', name: 'VEHICLE TRIM', sku: 'VT-024', price: 120.99, category: 'Interior', brand: 'BMW', stock: 38, image: VEHICLE_TRIM, selected: false },
      { id: '25', name: 'SEATS', sku: 'SE-025', price: 280.99, category: 'Interior', brand: 'BMW', stock: 20, image: SEATS, selected: false },
      { id: '26', name: 'SLIDING ROOF / FOLDING TOP', sku: 'SR-026', price: 450.99, category: 'Roof', brand: 'BMW', stock: 8, image: SLIDING_ROOF_FOLDING_TOP, selected: false },
      { id: '27', name: 'VEHICLE ELECTRICAL SYSTEM', sku: 'VE-027', price: 190.99, category: 'Electrical', brand: 'BMW', stock: 22, image: VEHICLE_ELECTRICAL_SYSTEM, selected: false },
      { id: '28', name: 'INSTRUMENTS, MEASURING SYSTEMS', sku: 'IM-028', price: 160.99, category: 'Instruments', brand: 'BMW', stock: 26, image: INSTRUMENTS_MEASURING_SYSTEMS, selected: false },
      { id: '29', name: 'LIGHTING', sku: 'LG-029', price: 110.99, category: 'Lighting', brand: 'BMW', stock: 40, image: LIGHTING, selected: false },
      { id: '30', name: 'HEATER AND AIR CONDITIONING', sku: 'HA-030', price: 220.99, category: 'Climate', brand: 'BMW', stock: 18, image: HEATER_AND_AIR_CONDITIONING, selected: false },
      { id: '31', name: 'AUDIO, NAVIGATION, ELECTRONIC SYSTEMS', sku: 'AN-031', price: 380.99, category: 'Electronics', brand: 'BMW', stock: 15, image: AUDIO_NAVIGATION_ELECTRONIC_SYSTEMS, selected: false },
      { id: '32', name: 'DISTANCE SYSTEMS, CRUISE CONTROL', sku: 'DC-032', price: 260.99, category: 'Safety', brand: 'BMW', stock: 19, image: DISTANCE_SYSTEMS_CRUISE_CONTROL, selected: false },
      { id: '33', name: 'EQUIPMENT PARTS', sku: 'EP-033', price: 90.99, category: 'Equipment', brand: 'BMW', stock: 35, image: EQUIPMENT_PARTS, selected: false },
      { id: '34', name: 'RESTRAINT SYSTEM AND ACCESSORIES', sku: 'RS-034', price: 200.99, category: 'Safety', brand: 'BMW', stock: 21, image: RESTRAINT_SYSTEM_AND_ACCESSORIES, selected: false },
      { id: '35', name: 'AUXILIARY MATERIALS, FLUIDS/COLORSYSTEM', sku: 'AM-035', price: 45.99, category: 'Fluids', brand: 'BMW', stock: 50, image: AUXILIARY_MATERIALS_FLUIDS_COLORSYSTEM, selected: false },
      { id: '36', name: 'COMMUNICATION SYSTEMS', sku: 'CS-036', price: 320.99, category: 'Communication', brand: 'BMW', stock: 12, image: COMMUNICATION_SYSTEMS, selected: false },
      { id: '37', name: 'VALUE PARTS&PACKAGES SERVICE AND REPAIR', sku: 'VP-037', price: 150.99, category: 'Service', brand: 'BMW', stock: 28, image: VALUE_PARTS_PACKAGES_SERVICE_AND_REPAIR, selected: false },
      { id: '38', name: 'INDIVIDUAL EQUIPMENT', sku: 'IE-038', price: 420.99, category: 'Customization', brand: 'BMW', stock: 10, image: INDIVIDUAL_EQUIPMENT, selected: false }
    ]
    setCatalogProducts(mockProducts)
    setSearchPerformed(true)
  }

  const handleProductSelect = (productId: string) => {
    setCatalogProducts(prev =>
      prev.map(p => p.id === productId ? { ...p, selected: !p.selected } : p)
    )
  }

  const handleAddSelected = () => {
    const selected = catalogProducts.filter(p => p.selected)
    console.log('Adding products:', selected)
  }

  const selectedCount = catalogProducts.filter(p => p.selected).length

  return (
    <>
      <style>{`
     
      `}</style>

      <div className="catalog-page">

        {/* Header */}
        <div className="catalog-header">
          <div className="catalog-header-left">
            <h1>Product Catalog</h1>
            <p>Select a BMW model to browse compatible parts</p>
          </div>
          <button className="btn-cancel">Cancel</button>
        </div>

        {/* Search Card */}
        <div className="search-card">
          <p className="search-card-title">Select Vehicle</p>
          <form onSubmit={handleSearch}>
            <div className="search-row">
              <div className="field-group">
                <label>BMW Model *</label>
                <select
                  className="field-select"
                  value={selectedModel}
                  onChange={(e) => { setSelectedModel(e.target.value); setSelectedYear('') }}
                  required
                >
                  <option value="">Select BMW model</option>
                  {bmwModels.map(m => (
                    <option key={m.id} value={m.id}>{m.name}</option>
                  ))}
                </select>
              </div>

              <div className="field-group">
                <label>Year *</label>
                <select
                  className="field-select"
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  required
                  disabled={!selectedModel}
                >
                  <option value="">Select year</option>
                  {getYears().map(y => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>

              <button className="btn-search" type="submit">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                  <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
                Search
              </button>
            </div>
          </form>
        </div>

        {searchPerformed && (
          <>
            <div className="results-header">
              <span className="results-title">Available Parts</span>
              <div className="results-meta">
                <span className="badge-count badge-total">{catalogProducts.length} found</span>
                {selectedCount > 0 && (
                  <span className="badge-count badge-selected">{selectedCount} selected</span>
                )}
              </div>
            </div>

            {catalogProducts.length > 0 ? (
              <>
                <div className="products-grid">
                  {catalogProducts.map(product => (
                    <div
                      key={product.id}
                      className={`product-card ${product.selected ? 'selected' : ''}`}
                      onClick={() => handleProductSelect(product.id)}
                    >
                      <div className="check-badge">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3">
                          <polyline points="20 6 9 17 4 12"/>
                        </svg>
                      </div>

                    
                      <div className="product-img-wrap">
                        <img src={product.image} alt={product.name} />
                      </div>

                      <div className="product-name">{product.name}</div>
                      <div className="product-brand">{product.brand} · {product.category}</div>
                      {/* <div className="product-price">${product.price.toFixed(2)}</div> */}
                      {/* <div className="product-stock">Stock: {product.stock}</div> */}
                    </div>
                  ))}
                </div>

                <div className="results-footer">
                  <span className="footer-hint">Click a product to select it</span>
                  <button
                    className="btn-add"
                    onClick={handleAddSelected}
                    disabled={selectedCount === 0}
                  >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                    </svg>
                    Add Selected ({selectedCount})
                  </button>
                </div>
              </>
            ) : (
              <div className="empty-state">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
                <p>No products found for this vehicle</p>
              </div>
            )}
          </>
        )}
      </div>
    </>
  )
}
