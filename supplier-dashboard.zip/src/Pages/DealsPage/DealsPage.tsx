import './DealsPage.css';
import { Search, ChevronDown, ChevronLeft, ChevronRight, BookOpen } from 'lucide-react';

export const DealsPage = () => {
  return (
    <div className="deals-page-container">
      <div className="deals-header">
        <h1>Deals</h1>
      </div>

      {/* Tabs */}
      <div className="deals-tabs-container">
        <div className="deals-tabs">
          <button className="tab-btn">My deals</button>
          <button className="tab-btn active">Category deals</button>
          <button className="tab-btn">Flash deals</button>
          <button className="tab-btn">
            Price drop <span className="tab-badge-new">New</span>
          </button>
          <button className="tab-btn">
            Commission drop <span className="tab-badge-new">New</span>
          </button>
          <button className="tab-btn">Imports</button>
        </div>
        
        <button className="about-deals-btn">
          <BookOpen size={16} /> About category deals
        </button>
      </div>

      {/* Main Content Area */}
      <div className="deals-content">
        {/* Filters */}
        <div className="deals-filters">
          <div className="search-input-wrapper">
            <input type="text" placeholder="Search by deal name..." />
            <div className="search-icon-wrapper">
              <Search size={18} color="#9ca3af" />
            </div>
          </div>
          
          <div className="filter-dropdowns">
            <div className="dropdown-btn status-dropdown">
              Status <ChevronDown size={16} />
            </div>
            <div className="dropdown-btn category-dropdown disabled">
              Category <ChevronDown size={16} color="#d1d5db" />
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="deals-table-container">
          <table className="deals-table">
            <thead>
              <tr>
                <th>Deal name</th>
                <th>Running date</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <div className="deal-name-cell">
                    <span className="deal-title">Big Ramadan Sale</span>
                    <span className="deal-subtitle">eg-feb26-brs</span>
                  </div>
                </td>
                <td>
                  <div className="running-date-cell">
                    <div className="date-row">
                      <span>25 Feb 26</span>
                      <ChevronRight size={14} color="#9ca3af" />
                      <span>19 Mar 26</span>
                    </div>
                    <div className="time-row">
                      <span>17:00 PM</span>
                      <span>22:00 PM</span>
                    </div>
                  </div>
                </td>
                <td>
                  <span className="status-badge ongoing">Ongoing</span>
                </td>
                <td className="action-cell">
                  <button className="btn-enroll">+ Enroll</button>
                </td>
              </tr>
              <tr>
                <td>
                  <div className="deal-name-cell">
                    <span className="deal-title">Toys Sale</span>
                    <span className="deal-subtitle">eg-mar26-toys-sale</span>
                  </div>
                </td>
                <td>
                  <div className="running-date-cell">
                    <div className="date-row">
                      <span>15 Mar 26</span>
                      <ChevronRight size={14} color="#9ca3af" />
                      <span>17 Mar 26</span>
                    </div>
                    <div className="time-row">
                      <span>17:00 PM</span>
                      <span>22:00 PM</span>
                    </div>
                  </div>
                </td>
                <td>
                  <span className="status-badge upcoming">Upcoming</span>
                </td>
                <td className="action-cell">
                  <button className="btn-enroll">+ Enroll</button>
                </td>
              </tr>
            </tbody>
          </table>

          {/* Table Footer */}
          <div className="table-footer">
            <span className="total-items">Total 2 items</span>
            <div className="pagination">
              <button className="page-nav disabled"><ChevronLeft size={16} /></button>
              <button className="page-num active">1</button>
              <button className="page-nav disabled"><ChevronRight size={16} /></button>
            </div>
          </div>
        </div>
      </div>

      {/* Side Tab */}
      <div className="rate-page-tab">
        <span className="star-icon">★</span> Rate this page
      </div>
    </div>
  );
};
