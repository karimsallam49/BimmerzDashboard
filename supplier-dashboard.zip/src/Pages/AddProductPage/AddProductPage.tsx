import './AddProductPage.css';
import { Search, ArrowRight } from 'lucide-react';

export const AddProductPage = () => {
  const categories = [
    "Apparel",
    "Audio & Video",
    "Bags & Luggage",
    "Bath",
    "Books",
    "Camera",
    "Cleaning & Hygiene"
  ];

  return (
    <div className="add-product-container">
      <div className="category-selection-card">
        
        {/* Header Section */}
        <div className="card-top-section">
          <h1 className="category-main-title">Category</h1>
          
          <div className="select-category-section">
            <h2 className="section-subtitle">Select Category</h2>
            
            <div className="search-input-box mb-4">
              <input type="text" placeholder="Search category" />
              <div className="search-icon-right">
                <Search size={18} color="#9ca3af" />
              </div>
            </div>

            <div className="category-list">
              {categories.map((category, index) => (
                <div className="category-list-item" key={index}>
                  <span>{category}</span>
                  <ArrowRight size={16} color="#9ca3af" className="arrow-icon" />
                </div>
              ))}
            </div>
          </div>

          <div className="or-divider">
            <span className="or-text">OR</span>
          </div>

          <div className="url-paste-section">
            <h2 className="section-subtitle">
              Paste noon PDP URL <span className="subtitle-hint">(By pasting the URL of a noon SKU here, you'll select the same category for this product.)</span>
            </h2>
            
            <div className="search-input-box mt-3">
              <input type="text" placeholder="Copy and paste the noon SKU link here" />
              <div className="search-icon-right">
                <Search size={18} color="#9ca3af" />
              </div>
            </div>
          </div>
        </div>

        {/* Footer Section */}
        <div className="card-footer-section">
          <button className="btn-next">Next</button>
        </div>

      </div>
    </div>
  );
};
